import os

class Config:
    SECRET_KEY = 'zffa_2(vwk4s@(yy)v4wvvri7f!$8hdmpz5_%&-nlbuj%kzqfs'
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'db.sqlite3')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
