from flask import Blueprint, request, jsonify
from .models import db, User, Book, Wishlist

wishlist_bp = Blueprint('wishlist', __name__)

@wishlist_bp.route('/wishlist', methods=['POST'])
def create_wishlist():
    data = request.json
    user_id = data.get('user_id')
    name = data.get('name')
    user = User.query.get(user_id)
    if not user:
        return jsonify({"error": "User not found"}), 404
    new_wishlist = Wishlist(name=name, user_id=user_id)
    db.session.add(new_wishlist)
    db.session.commit()
    return jsonify({"message": "Wishlist created"}), 201

@wishlist_bp.route('/wishlist/<int:wishlist_id>/book', methods=['POST'])
def add_book_to_wishlist(wishlist_id):
    data = request.json
    book_id = data.get('book_id')
    book = Book.query.get(book_id)
    wishlist = Wishlist.query.get(wishlist_id)
    if not book or not wishlist:
        return jsonify({"error": "Book or Wishlist not found"}), 404
    wishlist.books.append(book)
    db.session.commit()
    return jsonify({"message": "Book added to wishlist"}), 200

@wishlist_bp.route('/wishlist/<int:wishlist_id>/book', methods=['DELETE'])
def remove_book_from_wishlist(wishlist_id):
    data = request.json
    book_id = data.get('book_id')
    book = Book.query.get(book_id)
    wishlist = Wishlist.query.get(wishlist_id)
    if not book or not wishlist:
        return jsonify({"error": "Book or Wishlist not found"}), 404
    wishlist.books.remove(book)
    db.session.commit()
    return jsonify({"message": "Book removed from wishlist"}), 200

@wishlist_bp.route('/wishlist/<int:wishlist_id>/books', methods=['GET'])
def list_books_in_wishlist(wishlist_id):
    wishlist = Wishlist.query.get(wishlist_id)
    if not wishlist:
        return jsonify({"error": "Wishlist not found"}), 404
    books = [{"id": book.id, "title": book.title, "author": book.author} for book in wishlist.books]
    return jsonify(books), 200
