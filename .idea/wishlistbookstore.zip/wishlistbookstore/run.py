import sys
import os

print("Current working directory:", os.getcwd())
print("Python path:", sys.path)

try:
    from my_flask_app import create_app
except ImportError as e:
    print(f"ImportError: {e}")

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
